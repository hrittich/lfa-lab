########
Download
########

Releases
========

- `lfa-lab-0.3.0.tar.gz <releases/lfa-lab-0.3.0.tar.gz>` (2018-01-29)

Git Repository
==============

.. image:: https://travis-ci.org/hrittich/lfa-lab.svg?branch=master
    :target: https://travis-ci.org/hrittich/lfa-lab

- Clone the `GitHub repository <https://github.com/hrittich/lfa-lab>`_. You
  can use the following command::

    git clone https://github.com/hrittich/lfa-lab.git lfa-lab

