#######
License
#######

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

License FAQ
===========

- **Q**: I want to use LFA Lab for my research; do I have to publish my
  research results and plots under the GPL?

  **A**: No. You can do what you want with anything that you produce using
  LFA Lab.

- **Q**: I have written a program which uses LFA Lab; Do I have to publish the
  source code?

  **A**: No. If you want, you can keep your source code a secret. However, if
  you choose to publish your program or give your program to a collegue, you
  have to fulfill the requirements of the GPL.

License Text
============

.. literalinclude:: ../COPYING.txt

